 ___________________________________________________________________________________________________
|                                                                                                   |
|                                       Cookie Clicker                                              |
|                                                                                                   |
|                                      @@@@@@@@@@@@@@@@                                             |
|                                @@@@@@@%%%###%#%%#%%&@@@@@@@                                       |
|                            @@@@@%%%%##%#((%##(#(####%%%%%%@@@                                     |
|                          @@@&#%%%#&#%%%%%((#((/#(*((####((#%@@@@                                  |
|                        @@@%####%%%(((#(&&%%%%#/(%#(((((#(%#(%#%@@                                 |
|                       @@###((#&((&(((((#(#(#(/(/((/(#((#/#(#(&#%@@@                               |
|                      @@&%%%((##(#(((/#(/#/((///(((/(/(/(#(#(%(#%#%@@                              |
|                     @@%%##%#((((/#(//%#%%%%%,(.*///(/&#%%#%((%###%%@                              |
|                     @&%#%%####(/(/(/&%%##%%%%%,*.*(//%%%#%%&(#####%@@                             |
|                     @####%##((/*((*&%%%%%%%&&&***(///&(/(/((/#%(#%#%@                             |
|                     @%%%%#(&/#////((/&&%&%&**,*//(/(#*/(((((((#(#%##@                             |
|                     @%%#####(#%#/*,,,*///*(/**/*(*((#**/((#(##(#%%#%@                             |
|                     @@%%%##(#(((*/(*,/**&*//.(///**/(#/#%%&#######%@@                             |
|                      @%%#&#(((((((&%&&(*%##*/((((/((&%%&&(/((##%#%%@                              |
|                      @@%#######(##((/##%%%%&((%%##(&(((#(#(#(##%%&@@                              |
|                       @@&%&%%%#&#&%%&&&&&&%((&%%%%%%(((((##%#%#%@@@                               |
|                        @@@@%##%#####(##(((((%%&&&&&####(###%%%%@@                                 |
|                           @@@%%%#%######((#(#%(#(&#(#(###&%%@@@@                                  |
|                             @@@@%%%%#%%%#####%%%#####%%&%@@@@                                     |
|                                @@@@@@@&%%&%#%&%&&%&&@@@@@@                                        |
|                                      @@@@@@@@@@@@@@@@                 v. 2.031                    |
|                                                                                                   |
|———————————————————————————————————————————————————————————————————————————————————————————————————|
|                                                                                                   |
|                                   Thanks for Downloading!                                         |
|                    <!-- Code and graphics copyright Orteil, 2013-2021 -->                         |
|                                                                                                   |
|                                                                                                   |
|Cookie Clicker is made by Orteil, this is HIS game, NOT MINE.                                      |
|All I have done is made the page downloadable so you can play it unblocked. (REAL this time!)      |
|This is NOT FOR PROFIT, I NEVER DID and NEVER WILL make ANY money from this.                       |
|                                                                                                   |
|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
|                            The addons webpage I made myself!                                      |
|    Let me know some things you want me to add there on the comments of the download page!         |
|                                                                                                   |
|   If any assets in the game are missing, let me know on the comments of the download page!        |
|                           I will try to fix it as soon as I can.                                  |
|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
|                                                                                                   |
|Code and graphics copyright Orteil, 2013-2021:                                                     |
|Orteil's Twitter: https://twitter.com/orteil42                                                     |
|Orteil's Tumblr: https://orteil42.tumblr.com                                                       |
|Cookie Clicker Discord: https://discordapp.com/invite/cookie                                       |
|Cookie Clicker Merch: http://www.redbubble.com/people/dashnet                                      |
|Orteil's Patreon: https://www.patreon.com/dashnet                                                  |
|Cookie Clicker on Android: https://play.google.com/store/apps/details?id=org.dashnet.cookieclicker |
|Cookie Clicker on Steam: https://store.steampowered.com/app/1454400/Cookie_Clicker/                |
|                                                                                                   |
|Sushi8756 made this downoadable web version:                                                       |
|Sushi's Youtube: https://www.youtube.com/channel/UCP99woj07psKFyMQN56zMdg                          |
|Sushi's Scratch: https://scratch.mit.edu/users/Sushi8756/                                          |
|The Sushi8756 kaka Discord server: Not released yet!                                               |
|Sushi's Gamebanana: https://gamebanana.com/members/1721555                                         |
|Sushi on github: Sushi8756.github.io                                                               |
|                                                                                                   |
|———————————————————————————————————————————————————————————————————————————————————————————————————|
|              Tab                          v.s.                  Window                            |
|———————————————————————————————————————————————————————————————————————————————————————————————————|
|Playing in tab makes it easier to load          Playing in window looks nice, but it is harder     |
|bookmark addons/mods.                           to load bookmark addons/mods (still possible)      |
|———————————————————————————————————————————————————————————————————————————————————————————————————|
|                                                                                                   |
|                                                                                                   |
|                                         Credits                                                   |
|                                                                                                   |
|           (These are in the page itself, in the "Other Versions" dropdown)                        |
|                                                                                                   |
|https://orteil.dashnet.org/cookieclicker/                     ←   Official Site (Recent Version)   |
|https://wackube.github.io/Cookie_Clicker/                     ←   v. 2.031 site 1                  |
|http://ozh.github.io/cookieclicker/                           ←   v. 2.031 site 2                  |
|https://funneljai212.github.io/cookie-clicker-source-code-1   ←   v. 2.031 site 3                  |
|https://xenogames224.github.io/cookieclickerxeno/             ←   v. 2.022                         |
|https://trixter9994.github.io/Cookie-Clicker-Source-Code      ←   v. 2.021 beta site 1             |
|https://3kh0.github.io/cookie-clicker                         ←   v. 2.021 beta site 2             |
|https://wolfy01.github.io/Cookie-Clicker                      ←   v. 2.0042                        |
|https://eli-schwartz.github.io/cookieclicker                  ←   v. 1.0411                        |
|___________________________________________________________________________________________________|